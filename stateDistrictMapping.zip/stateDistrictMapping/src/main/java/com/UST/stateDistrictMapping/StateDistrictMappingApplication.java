package com.UST.stateDistrictMapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StateDistrictMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StateDistrictMappingApplication.class, args);
	}

}
